﻿//1st effect- If user clicks on paragrah, text will change it's positon at random spot at the screen.
$(document).ready(function () {
    $("p").each(function () {
        $(this).click(function () {
            MoveParagraphRandomly(this);
        });
    });

function GetRandomPosition() {
        var x = Math.floor(Math.random() * (window.innerWidth - 200));
        var y = Math.floor(Math.random() * (window.innerHeight - 100));
        return { x: x, y: y };
    }
function MoveParagraphRandomly(p) {
        var position = GetRandomPosition();
        p.style.position = 'absolute';
        p.style.top = position.y + 'px';
        p.style.left = position.x + 'px';
       
    }

//2end effect. When user clicks on list, text replases on "Ouch! Dude, that hurts ("
$("li").click(function () {
    $(this).text("Ouch! Dude, that hurts...");
});



});
//Animation to destroy images. Image will всасёться
$(document).ready(function () {
    $("img").click(function () {
        $(this).animate({
            width: "toggle", 
        }, 2000);
    });
});




